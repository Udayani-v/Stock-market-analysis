#The program merges data of 3 companies each from each domain.It then calculates the aggregate
#of the turnover of each domain for dates shared by all companies in that domain.The respective merged files are the exported as a csv format
#These files are taken on tableau Datasources and visualizations have thus been created.
#Companies considered -
#Steel - vssl,jsw,tata steel
#Consumer goods - godrej,Britannia,Dabur
#Banks- Corporation Bank,yes bank,Kotak Mahindra Bank

#install.packages("lubridate")
library(lubridate)
#Various operations on the date attribute- extraction of year,month,day,returning year,month,day attributes,parsing of the date attribute

setwd("C:/Users/Admin/Desktop/CODE/Saachi")
#Read csv files from file path , used as dataframe
NSE.BRITANNIA <- read.csv("Data analytics csv datasets/NSE-BRITANNIA.csv")
NSE.DABUR <- read.csv("Data analytics csv datasets/NSE-DABUR.csv")
NSE.GODREJCP <- read.csv("Data analytics csv datasets/NSE-GODREJCP.csv")
NSE.YESBANK <- read.csv("Data analytics csv datasets/NSE-YESBANK.csv")
NSE.JSWSTEEL <- read.csv("Data analytics csv datasets/NSE-JSWSTEEL.csv")
NSE.VSSL <- read.csv("Data analytics csv datasets/NSE-VSSL.csv")
NSE.TATASTEEL <- read.csv("Data analytics csv datasets/NSE-TATASTEEL.csv")
NSE.KOTAKBANK <- read.csv("Data analytics csv datasets/NSE-KOTAKBANK.csv")
NSE.CORPBANK <- read.csv("Data analytics csv datasets/NSE-CORPBANK.csv")
#Since we are dealing with stock data the best way to deal with NA values is to delete the row w
#with it,since we daily data over many years.
nse_brit_clean<-NSE.BRITANNIA[-4643:-4644,1:8]
nse_dabur_clean<-NSE.DABUR[-4644,1:8]
NSE.CORPBANK<-NSE.CORPBANK[-4643,]
#Assigning A name field to each dataset
nse_dabur_clean$Name="Dabur"
nse_brit_clean$Name="Britannia "
NSE.GODREJCP$Name="Godrej"
NSE.VSSL$Name<-"VSSL"
NSE.JSWSTEEL$Name<-"JSW"
NSE.TATASTEEL$Name<-"Tata"
NSE.KOTAKBANK$Name="Kotak"
NSE.YESBANK$Name="Yes Bank"
NSE.CORPBANK$Name="Corporation Bank"
#Converting into Date from csv file to Date format,for extraction
date_godrej<-as.Date(NSE.GODREJCP$Date,"%Y-%m-%d")
#Extraction of year and adding the year attribute to the Godrej dataframe
NSE.GODREJCP$year<-as.numeric(format(date_godrej, "%Y"))
date_brit<-as.Date(nse_brit_clean$Date,"%Y-%m-%d")
nse_brit_clean$year<-as.numeric(format(date_brit, "%Y"))
#Creating a subset - a new dataframe for the Britannia dataset for years 2010-2016
test_brit<-subset(nse_brit_clean,nse_brit_clean$year>=2010)
date_dabur<-as.Date(nse_dabur_clean$Date,"%Y-%m-%d")
nse_dabur_clean$year<-as.numeric(format(date_dabur, "%Y"))
#Subset for Dabur - 2010-2016
test_dabur<-subset(nse_dabur_clean,nse_dabur_clean$year>=2010)
#Using Dateformat,extraction of year and adding year to respective dataframes,same format used for the rest of the companies
date_yesbank<-as.Date(NSE.YESBANK$Date,"%Y-%m-%d")                                                                   
NSE.YESBANK$year<-as.numeric(format(date_yesbank, "%Y"))
date_corpk<-as.Date(NSE.CORPBANK$Date,"%Y-%m-%d")
NSE.CORPBANK$year<-as.numeric(format(date_corpk, "%Y"))
date_kotak<-as.Date(NSE.KOTAKBANK$Date,"%Y-%m-%d")
NSE.KOTAKBANK$year<-as.numeric(format(date_kotak, "%Y"))
#subset for Kotak - 2010-2016
test_kotak<-subset(NSE.KOTAKBANK,NSE.KOTAKBANK$year>=2010)
date_jsw<-as.Date(NSE.JSWSTEEL$Date,"%Y-%m-%d")  
NSE.CORPBANK$year<-as.numeric(format(date_corpk, "%Y"))
date_jsw<-as.Date(NSE.JSWSTEEL$Date,"%Y-%m-%d")  
NSE.JSWSTEEL$year<-as.numeric(format(date_jsw, "%Y"))
date_VSSL<-as.Date(NSE.VSSL$Date,"%Y-%m-%d")  
NSE.VSSL$year<-as.numeric(format(date_VSSL, "%Y"))
date_TATA<-as.Date(NSE.TATASTEEL$Date,"%Y-%m-%d")  
NSE.TATASTEEL$year<-as.numeric(format(date_TATA, "%Y"))
#subset tata - 2010-2016
TEST_tata<-subset(NSE.TATASTEEL,NSE.TATASTEEL$year>=2010)
#The merge functions uses a common attribute from two dataframes ,and merges them according to common value of the mapping attribute
#her the mapping attribute is Date - only common Dates between the two comapnies will be in the merged dataframe
test_merge1<-merge(test_brit,test_dabur,by="Date")    
#Merging Another dataframe to the merged dataframe
test_merge2<-merge(test_merge1,NSE.GODREJCP,BY="Date")
#calculate aggregate turnover for Consumer goods.
test_merge2$Total_Turnover<-test_merge2$Turnover..Lacs..x+test_merge2$Turnover..Lacs..y+test_merge2$Turnover..Lacs.
#export merged data as csv file to be used as datasource in Tableau
write.csv(test_merge2, "Consumer.csv", row.names=FALSE)
#Same format followed for banks,steel comapnies.
test_steel<-merge(TEST_tata,NSE.VSSL,by="Date")
test_steel1<-merge(test_steel,NSE.JSWSTEEL,by="Date")
#Calculate aggregate turnover for the steel industries
test_steel1$Total_turnover<-test_steel1$Turnover..Lacs.+test_steel1$Turnover..Lacs..x+test_steel1$Turnover..Lacs..y
write.csv(test_steel1,"steel.csv",row.names = FALSE)
merge_bank<-merge(test_kotak,NSE.YESBANK , by="Date")
merge_bank1<-merge(merge_bank,NSE.CORPBANK,by="Date")
#Calculate aggregate turnover for banks
merge_bank1$Total_turnov<-merge_bank1$Turnover..Lacs..x+merge_bank1$Turnover..Lacs..y+merge_bank1$Turnover..Lacs.
write.csv(merge_bank1,"bank.csv",row.names=FALSE)

