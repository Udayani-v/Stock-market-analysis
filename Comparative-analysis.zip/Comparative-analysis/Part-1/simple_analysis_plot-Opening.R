#simple plot for stock attribute performance of a particular company for a year
#plots for Britannia and Tata steel - 2016 done here.
#install.packages("lubridate")

setwd("C:/Users/Admin/Desktop/CODE/Saachi")

library("lubridate")
#Read csv files from file path , used as dataframe
NSE.BRITANNIA <- read.csv("Data analytics csv datasets/NSE-BRITANNIA.csv")
NSE.TATASTEEL <- read.csv("Data analytics csv datasets/NSE-TATASTEEL.csv")
#Since we are dealing with stock data the best way to deal with NA values is to delete the row w
#with it,since we daily data over many years.
nse_brit_clean<-NSE.BRITANNIA[-4643:-4644,1:8]
#Assigning Names
nse_brit_clean$Name="Britannia "
NSE.TATASTEEL$Name<-"Tata"
#Britannia
#Date conversion,extraction
date_brit<-as.Date(nse_brit_clean$Date,"%Y-%m-%d")
nse_brit_clean$year<-as.numeric(format(date_brit, "%Y"))
test_brit<-subset(nse_brit_clean,nse_brit_clean$year>=2010)
#Subset Year 2016
test_brit_2016<-subset(nse_brit_clean,nse_brit_clean$year==2016)
#Tata
#Date Conversion Extraction
date_TATA<-as.Date(NSE.TATASTEEL$Date,"%Y-%m-%d")  
NSE.TATASTEEL$year<-as.numeric(format(date_TATA, "%Y"))
TEST_tata<-subset(NSE.TATASTEEL,NSE.TATASTEEL$year>=2010)
#Subset  Year 2016
TEST_tata_2016<-subset(NSE.TATASTEEL,NSE.TATASTEEL$year==2016)
#For year 2016 
#plot for Britannia 2016
plot(as.Date(test_brit_2016$Date, "%Y-%m-%d"), test_brit_2016$Open, xlab = "Dates", ylab = "Opening price",
     type = "l", col = "red", main = "Openeing price of Britannia for past 1 year") #Attribute Opening Price
#plot for tata steel 2016.
plot(as.Date(TEST_tata_2016$Date, "%Y-%m-%d"), TEST_tata_2016$Open, xlab = "Dates", ylab = "Opening price",
     type = "l", col = "red", main = "Opening price of Tata Steel for past 1 year")   #Attribute Opening Price
