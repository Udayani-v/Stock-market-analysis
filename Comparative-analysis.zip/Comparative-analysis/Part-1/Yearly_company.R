#programs analyzes stock attribute trends over years for a particular company
#Attributes Taken into consideration:Opening Price,Closing Price,Hig,Low for attribute - Date
#install.packages("lubridate")
#install.packages("ggplot2")
library(lubridate) #Various operations on the date attribute- extraction of year,month,day,returning year,month,day attributes,parsing of the date attribute
library(ggplot2) #Takes year as a factor, days of the year on x axis,stock attribute on the y axis

setwd("C:/Users/Admin/Desktop/CODE/Saachi")

NSE.BRITANNIA <- read.csv("Data analytics csv datasets/NSE-BRITANNIA.csv")
NSE.DABUR <- read.csv("Data analytics csv datasets/NSE-DABUR.csv")
NSE.GODREJCP <- read.csv("Data analytics csv datasets/NSE-GODREJCP.csv")
NSE.YESBANK <- read.csv("Data analytics csv datasets/NSE-YESBANK.csv")
#dabur
#Date format conversion,year extraction
date_dabur<- as.Date(NSE.DABUR$Date,"%Y-%m-%d")
 NSE.DABUR$year<-as.numeric(format(date_dabur, "%Y"))
#Subset for dabur 2010-2016
Dabur_test1<-subset(NSE.DABUR,NSE.DABUR$year>=2010)
ggplot(Dabur_test1, aes(x=yday(Dabur_test1$Date), y=Dabur_test1$Open, color=factor(year(Dabur_test1$Date)))) +geom_line() #Line plot,Openng price
ggplot(Dabur_test1, aes(x=yday(Dabur_test1$Date), y=Dabur_test1$Low, color=factor(year(Dabur_test1$Date)))) +geom_line()  #Low price
#Britannia - date format coversion,extraction
date_brit<- as.Date(NSE.BRITANNIA$Date,"%Y-%m-%d")
NSE.BRITANNIA$year<-as.numeric(format(date_brit, "%Y"))
#Subset years 2010-16
Britannia_test1<-subset(NSE.BRITANNIA,NSE.BRITANNIA$year>=2010)
#Subset years - 2005-10
Britannia_test2<-subset(NSE.BRITANNIA,NSE.BRITANNIA$year<=2010 & NSE.BRITANNIA$year>=2005)
ggplot(Britannia_test1, aes(x=yday(Britannia_test1$Date), y=Britannia_test1$Open, color=factor(year(Britannia_test1$Date)))) +geom_line() #Opening Price
ggplot(Britannia_test1, aes(x=yday(Britannia_test1$Date), y=Britannia_test1$Close, color=factor(year(Britannia_test1$Date)))) +geom_line() #Closing Price
ggplot(Britannia_test1, aes(x=yday(Britannia_test1$Date), y=Britannia_test1$High, color=factor(year(Britannia_test1$Date)))) +geom_line()   #High Price

ggplot(Britannia_test1, aes(x=yday(Britannia_test1$Date), y=Britannia_test1$Low, color=factor(year(Britannia_test1$Date)))) +geom_line()     #Low price
ggplot(Britannia_test2, aes(x=yday(Britannia_test2$Date), y=Britannia_test2$Open, color=factor(year(Britannia_test2$Date)))) +geom_line()
ggplot(Britannia_test1, aes(x=yday(Britannia_test1$Date), y=Britannia_test1$Low, color=factor(year(Britannia_test1$Date)))) +geom_line()
#Godrej - date format coversion,extraction
date_god<- as.Date(NSE.GODREJCP$Date,"%Y-%m-%d")
NSE.GODREJCP$year<-as.numeric(format(date_god, "%Y"))
#Subset years - 2010-16
Godrej_test1<-subset(NSE.GODREJCP,NSE.GODREJCP$year>=2010)
ggplot(Godrej_test1, aes(x=yday(Godrej_test1$Date), y=Godrej_test1$Close, color=factor(year(Godrej_test1$Date)))) +geom_line()
ggplot(Godrej_test1, aes(x=yday(Godrej_test1$Date), y=Godrej_test1$Low, color=factor(year(Godrej_test1$Date)))) +geom_line()
ggplot(Godrej_test1, aes(x=yday(Godrej_test1$Date), y=Godrej_test1$Open, color=factor(year(Godrej_test1$Date)))) +geom_line()
ggplot(Godrej_test1, aes(x=yday(Godrej_test1$Date), y=Godrej_test1$High, color=factor(year(Godrej_test1$Date)))) +geom_line()
#Yes Bank - date format coversion,extraction
date_yesbank<- as.Date(NSE.YESBANK$Date,"%Y-%m-%d")
NSE.YESBANK$year<-as.numeric(format(date_yesbank, "%Y"))
#Subset years - 2010-16
yes_test1<-subset(NSE.YESBANK,NSE.YESBANK$year>=2010)
ggplot(yes_test1, aes(x=yday(yes_test1$Date), y=yes_test1$Close, color=factor(year(yes_test1$Date)))) +geom_line()

