#Constructing a scatterplot Matrix for all attributes with respect to the following attributes
#Opening Price,Total Trade Quantity, Turnover. for the following banks:
#--Corporation Bank.
#--Yes Bank.
#--EBank.
#--Kotak Bank.

setwd("C:/Users/Admin/Desktop/CODE/Spoorti")
#Cleansing the data:
#Since we are dealing with stock data the best way to deal with NA values is to delete the row w
#with it,since we daily data over many years.
#BANKS-1-
nse_corp<-read.csv("Data Analytics Datasets/NSE_CORPBANK_new.csv")
nse_corp_clean<-nse_corp[-4644,1:8]

nse_yesbank<-read.csv("Data Analytics Datasets/NSE_YESBANK_new.csv")
nse_ebank<-read.csv("Data Analytics Datasets/NSE_EBANK_new.csv")
nse_kotakbank<-read.csv("Data Analytics Datasets/NSE_KOTAK_new.csv")

#sapply(nse_yesbank, is.numeric)->To check for numeric attributes.
#nse_yesbank$Date=NULL#Removes Date coloumn
#print(nse_yesbank)

#Making a dataframe for for each of the specified banks.
nyb<-data.frame(nse_yesbank)
cbank<-data.frame(nse_corp_clean)
yesb<-data.frame(nse_yesbank)
kotakb<-data.frame(nse_kotakbank)

#Plotting a scatterplot matrix with the help of pairs() function and finding out the correlation
#With respect to Opening Price and TurnOver.
pairs(~Open+Turnover..Lacs.+Total.Trade.Quantity,data=nyb,main="ScatterplotMatrix for Yes Bank")
cor(nse_yesbank$Open,nse_yesbank$Turnover..Lacs.)

pairs(~Open+Turnover..Lacs.+Total.Trade.Quantity,data=kotakb,main="ScatterplotMatrix for Kotak Bank")
cor(nse_kotakbank$Open,nse_kotakbank$Turnover..Lacs.)

pairs(~Open+Turnover..Lacs.+Total.Trade.Quantity,data=cbank,main="ScatterplotMatrix for Corporation Bank")
cor(nse_corp$Open,nse_corp$Turnover..Lacs.,use="complete")#Ignoring NA values.

pairs(~Open+Turnover..Lacs.+Total.Trade.Quantity,data=ebank,main="ScatterplotMatrix for EBank")
cor(nse_ebank$Open,nse_ebank$Turnover..Lacs.)

#Correlation Values:
#Yes Bank-0.6149974
#Kotak Bank-0.352273
#Corporation Bank-0.280222
#EBank- -0.05713695

#Since,Yes Bank has higly positive correlation with Turnover and Opening price we can say that
#Opening price does affect the turover of Yes Bank.