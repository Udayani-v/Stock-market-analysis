#Comparison of closing prices among steel industries.
#dygraph() needs xts time series objects.
#install.packages("dygraphs")

setwd("C:/Users/Admin/Desktop/CODE/Spoorti")

library("dygraphs")
library("xts")

#Reading the csv files.
tatasteel<-read.csv("Data Analytics Datasets/TATASTEEL_new.csv")
vssl<-read.csv("Data Analytics Datasets/VSSL_new.csv")
jswsteel<-read.csv("Data Analytics Datasets/JSWSTEEL_new.csv")

#Extracting the specified yeaar for all steel comapnies.
date1<- as.Date(tatasteel$Date,"%Y-%m-%d")
tatasteel$year<-as.numeric(format(date1, "%Y"))
tatasteel_years<-subset(tatasteel,tatasteel$year==2016)

date2<- as.Date(vssl$Date,"%Y-%m-%d")
vssl$year<-as.numeric(format(date2, "%Y"))
vssl_years<-subset(vssl,vssl$year==2016)

date4<- as.Date(jswsteel$Date,"%Y-%m-%d")
jswsteel$year<-as.numeric(format(date4, "%Y"))
jswsteel_years<-subset(jswsteel,jswsteel$year==2016)

#Currently acceptable classes include: 'Date', 'POSIXct', 'timeDate',
#as well as 'yearmon' and 'yearqtr' where the index values remain unique.

#Using xts objects(which handles time-series data) 
#and plotting the graph using the dygraphs.
#Frequency=365 indicates that X-Axis is consists og days 1-365.
tatasteel_xts <- xts(tatasteel_years$Close,order.by=as.POSIXct(tatasteel_years$Date),frequency=365)
vssl_xts <- xts(vssl_years$Close,order.by=as.POSIXct(vssl_years$Date),frequency=365)
jswsteel_xts <- xts(jswsteel_years$Close,order.by=as.POSIXct(jswsteel_years$Date),frequency=365)

#Binding the plots in one graph for all comapnies.
stocks <- cbind(tatasteel_xts,vssl_xts,jswsteel_xts)

#The dygraphs package is an R interface to the dygraphs JavaScript charting library.
#It provides rich facilities for charting time-series data in R.
dygraph(stocks,ylab="Closing Pice",
        main="Closing prices of all Steel Industries") %>%
  dySeries("..1",label="TATASTEEL") %>%
  dySeries("..2",label="VSSL") %>%
  dySeries("..3",label="JSWSTEEL") %>%
  dyOptions(colors = c("blue","red","green")) %>%
  dyRangeSelector()
# ******************************************************************************
#Comparing Turnover of competing Steel Industries.

tatasteel_xts <- xts(tatasteel_years$Turnover,order.by=as.POSIXct(tatasteel_years$Date),frequency=365)
vssl_xts <- xts(vssl_years$Turnover,order.by=as.POSIXct(vssl_years$Date),frequency=365)
jswsteel_xts <- xts(jswsteel_years$Turnover,order.by=as.POSIXct(jswsteel_years$Date),frequency=365)

#Binding the plots of all companies in one plot.
stocks <- cbind(tatasteel_xts,jswsteel_xts)

#lotting the graph using dygraphs.
dygraph(stocks,ylab="TurnOver",
        main="TurnOverof all Competing Steel Industries") %>%
  dySeries("..1",label="TATASTEEL") %>%
  #dySeries("..2",label="VSSL") %>%
  #dySeries("..3",label="LLOYD") %>%
  dySeries("..2",label="JSWSTEEL") %>%
  dyOptions(colors = c("orange","blue")) %>%
  dyRangeSelector()
# ********************************************************************************
#Comparing High prices of all companies of Steel industry.
tatasteel_xts <- xts(tatasteel_years$High,order.by=as.POSIXct(tatasteel_years$Date),frequency=365)
vssl_xts <- xts(vssl_years$High,order.by=as.POSIXct(vssl_years$Date),frequency=365)
jswsteel_xts <- xts(jswsteel_years$High,order.by=as.POSIXct(jswsteel_years$Date),frequency=365)

#Binding the plots of all companies in one plot.
stocks <- cbind(tatasteel_xts,vssl_xts,jswsteel_xts)

#plotting the graph using dygraphs.
dygraph(stocks,ylab="TurnOver",
        main="High Prices of all Competing Steel Industries") %>%
  dySeries("..1",label="TATASTEEL") %>%
  dySeries("..2",label="VSSL") %>%
  #dySeries("..3",label="LLOYD") %>%
  dySeries("..3",label="JSWSTEEL") %>%
  dyOptions(colors = c("orange","blue","red")) %>%
  dyRangeSelector()
# *******************************************************************************

#Comparing TurnOver for all consumer companies.
brit<-read.csv("Data Analytics Datasets/NSE-BRITANNIA_new.csv")
brit_clean<-brit[-4642,1:8]

dabur<-read.csv("Data Analytics Datasets/NSE_DABUR_new.csv")
dabur_clean<-dabur[-4644,1:8]

godrej<-read.csv("Data Analytics Datasets/NSE_GODREJ_new.csv")

date1<- as.Date(dabur$Date,"%Y-%m-%d")
dabur$year<-as.numeric(format(date1, "%Y"))
dabur_years<-subset(dabur,dabur$year==2016)

date2<- as.Date(brit$Date,"%Y-%m-%d")
brit$year<-as.numeric(format(date2, "%Y"))
brit_years<-subset(brit,brit$year==2016)

date4<- as.Date(godrej$Date,"%Y-%m-%d")
godrej$year<-as.numeric(format(date4, "%Y"))
godrej_years<-subset(godrej,godrej$year==2016)

#Currently acceptable classes include: 'Date', 'POSIXct', 'timeDate',
#as well as 'yearmon' and 'yearqtr' where the index values remain unique.

#Using xts objects(which handles time-series data) 
#and plotting the graph using the dygraphs.
#Frequency=365 indicates that X-Axis is consists og days 1-365.
dabur_xts <- xts(dabur_years$Turnover..Lacs.,order.by=as.POSIXct(dabur_years$Date),frequency=365)
brit_xts <- xts(brit_years$Turnover..Lacs.,order.by=as.POSIXct(brit_years$Date),frequency=365)
godrej_xts <- xts(godrej_years$Turnover..Lacs.,order.by=as.POSIXct(godrej_years$Date),frequency=365)


#Binding the plots in one graph for all comapnies.
stocks <- cbind(dabur_xts,brit_xts,godrej_xts)

#plotting the graph using dygraphs.
dygraph(stocks,ylab="TurnOver",
        main="TurnOver of all Competing Consumer Companies") %>%
  dySeries("..1",label="TATASTEEL") %>%
  dySeries("..2",label="VSSL") %>%
  #dySeries("..3",label="LLOYD") %>%
  dySeries("..3",label="JSWSTEEL") %>%
  dyOptions(colors = c("blue","purple","red")) %>%
  dyRangeSelector()
# ******************************************************************************

