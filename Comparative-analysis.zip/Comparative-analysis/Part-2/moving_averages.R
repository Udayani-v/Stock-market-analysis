#Simple Moving averages for NSE-KOTAK BANK.
#install.packages("fpp")
#The following libraries have been used for the moving averages.
#This library is used to deal with time series data.
library("TTR")
#This library is used to deal with analysis and prediction part for time-series data.
library("forecast")
#This library is also used for forecating(Forecasting principles and practice.)purposes
library("fpp")

setwd("C:/Users/Admin/Desktop/CODE/Spoorti")

nse_kotakbank<-read.csv("Data Analytics Datasets/NSE_KOTAK_new.csv")
#Initially seeing the variation of data with respect to all attributes.
plot(as.ts(nse_kotakbank),main="Variation of all attributes for Kotak Bank")

#Calculating the moving average values with an order of 10.
MA_values<-ma(nse_kotakbank,order=10,centre=TRUE)#window size=10
plot(as.ts(MA_values),main="Moving Averages for Kotak Bank",col="blue")

#Function for calculating the trend in the data.
time_series=tail(head(nse_kotakbank, 17*4+2),17*4-4)
trend= ma(time_series,order=5,centre=T)
plot(as.ts(trend),main="Trend for Kotak Bank",col="orange")
# ************************************************************************
#For DABUR Consumer goods company.
nse_dabur_clean<-read.csv("Data Analytics Datasets/NSE_DABUR_new.csv")

plot(as.ts(nse_dabur_clean),main="Variation of all attributes for Dabur")
#Calculating the moving average values with an order of 10.
MA_values<-ma(nse_dabur_clean,order=10,centre=TRUE)#window size=10
plot(as.ts(MA_values),main="Moving Averages for Dabur",col="red")

#Function for calculating the trend in the data.
ts=tail(head(nse_dabur_clean, 17*4+2),17*4-4)
trend= ma(ts,order=10,centre=T)
plot(as.ts(trend),main="Trend for Dabur",col="darkgreen")
# *************************************************************************
#For VSSL Steel Company.
vssl<-read.csv("Data Analytics Datasets/VSSL_new.csv")

plot(as.ts(vssl),main="Variation of all attributes for VSSL")
#Calculating the moving average values with an order of 10.
MA_values<-ma(vssl,order=10,centre=TRUE)#window size=10
plot(as.ts(MA_values),main="Moving Averages for VSSL",col="purple")

#Function for calculating the trend in the data.
ts=tail(head(vssl, 17*4+2),17*4-4)
trend= ma(ts,order=10,centre=T)
plot(as.ts(trend),main="Trend for VSSL",col="blue")

#****************************************************************************
