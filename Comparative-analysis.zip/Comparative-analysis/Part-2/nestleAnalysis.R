#Plotting Nestle's TurnOver and and seeing how the company's turnover changed due to
#the Maggi Noodle crisis.We can observe a clear dip in the turnover.

#Functions to work with date-times and time-spans:
#fast and user friendly parsing of date-time data, 
#extraction and updating of components of a date-time (years, months, days, hours, minutes, and seconds),
#algebraic manipulation on date-time and time-span objects. 
#The 'lubridate' package has a consistent and memorable syntax that makes working
#with dates easy and fun.
setwd("C:/Users/Admin/Desktop/CODE/Spoorti")
library(lubridate)
#For extraction of dates.
library(ggplot2) 
#For plooting the data.

#Reading the CSV file.
Nestle<-read.csv("Data Analytics Datasets/NSE_NESTLE_new.csv")
date1<-as.Date(Nestle$Date,"%Y-%m-%d")
Nestle$year<-as.numeric(format(date1, "%Y"))

#Extracting the specified year.
#2015 was when the crisis happended(June).
#X axis is days in a year(1-365)
Nestle_test1<-subset(Nestle,Nestle$year>=2015)
ggplot(Nestle_test1, aes(x=yday(Nestle_test1$Date), y=Nestle_test1$Turnover..Lacs., color=factor(year(Nestle_test1$Date))))+geom_line()+ggtitle("TurnoverDip of Nestle due to Maggi Noodles Crisis") +
  labs(x="Days",y="Turnover") 

#Plotting the varition of all attributes over a period of 6 years(2010-2016).
plot(as.ts(Nestle),main="Variation of all attributes for Nestle")

