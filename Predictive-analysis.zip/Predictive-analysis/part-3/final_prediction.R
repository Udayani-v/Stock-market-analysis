library(forecast)   
library(fpp)
library(ggplot2)
library(scales)
install.packages("readr")
install.packages("stringr")
library(readr)
library(stringr)
library(lubridate)
setwd("C:/Users/Admin/Desktop/CODE/Sai Manasa NC")

stockList="C:/Users/Admin/Desktop/CODE/Sai Manasa NC/File_Names.txt"
#stockList contains the names of the data files
dateList="C:/Users/Admin/Desktop/CODE/Sai Manasa NC/Dates_Companies.txt"
#dataList contains all the dates needed for time-series analysis for a dataset
#- e.g. starting date, date to split training and testing data by

if(file.exists(stockList) == TRUE & file.info(stockList)$isdir == FALSE & file.info(stockList)$size > 0)
{
  print("***************************")
  opener1 = file(stockList,open = "r")
  opener2 = file(dateList,open = "r")
  reader1 = readLines(opener1, warn = FALSE)
  reader2 = readLines(opener2, warn = FALSE)
  #readers traverse through the files
  
  #t <- read.csv(reader1[1])
  for(i in 1:length(reader))
  {
    filePath = reader[i]
    if(fileName != "")
    {
      if(file.exists(filePath) & file.info(filePath)$size > 0)
      {
        textData <- read.csv(file = filePath, header = TRUE)
        name <- strsplit(reader1[i],"/")
        print(name[[1]][5])
        time_series(textData,reader2[i],filePath)
      }
    }
  }
        
}
#print DABUR.csv instead of entire filename
time_series <- function(textData,a,filePath)
{
  b<-strsplit(a,",")
  #splits lines in dataList to get individual values
  tsData = ts(rev(textData$Close),start=c(b[[1]][1],b[[1]][2]),frequency=365)
  #creating a time series object with the columns reversed as the oldest values have to come first
  #closing price is used for the time-series analysis
  
  trainData = window(tsData, end=c(b[[1]][3],b[[1]][4]))
  testData = window(tsData, start=c(b[[1]][5],b[[1]][6]))
  #splitting the data into training and testing sets
  
  display(trainData,testData)
  fitData = auto.arima(trainData)
  #auto.arima function automatically caluclates the best possible values for p,d,q values of arima(p,d,q)
  
  forecastData = forecast(fitData, h=length(testData))
  #the data is forecasted
  
  write.csv(testData,file=filePath)
  write.csv(forecastData=filePath,append=TRUE)
  #the changes are written back to the file
  
  forecast <- as.data.frame(read.csv(filePath))
  graph(forecast)
  error(forecast)
}
display <- function(trainData,testData)
{
  print("Length of training set: ")
  print(length(trainData))
  print("Length of testing set: ")
  print(length(testData))
}
graph <- function(forecast)
{
      
   ggplot(x,aes(nrow(x):1)) + geom_line(aes(y = x$test, colour = "test" ))
    + geom_line(aes(y = x$forecast, colour = "forecast")) 
  #plot(forecast[,2],type="l",col="red")
  #lines(forecast[,1],type='l',col="green")
}

error <- function(forecast)
{
  sumError=0
  perError=0
  #print(forecast[1,1])
  for(i in 1:length(forecast[,2]))
  {
    sumError=sumError+abs(forecast[i,1]-forecast[i,2])
    perError=perError+(abs(forecast[i,1]-forecast[i,2])/forecast[i,1])
  }
  print("Total Error:")
  print(sumError)
  print("Average Error:")
  print(sumError/length(forecast))
  print("Percentage Error:")
  print((perError/length(forecast))*100)
  #to compute the error 
}

#computes the best time to buy - lowest stock price
a<-which(forecast[,2]==min(forecast[,2]),arr.ind=TRUE)
print(paste("Best time to buy: ",forecast[a[1],3]))
print(paste("Stock price: ",min(forecast[,2])))

#computes the best time to sell - highest stock price
b<-which(forecast[,2]==max(forecast[,2]),arr.ind=TRUE)
print(paste("Best time to sell: ",forecast[b[1],3]))
print(paste("Stock price: ",max(forecast[,2])))
