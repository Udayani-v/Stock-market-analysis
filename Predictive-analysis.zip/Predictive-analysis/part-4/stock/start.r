setwd("C:/Users/Rajani/Desktop/stock")


#BANKS-1-
nse_corp<-read.csv("NSE_CORPBANK_new.csv")
b1<-nse_corp[-4644,1:8]

b2<-read.csv("NSE_EBANK_new.csv")
b3<-read.csv("NSE_KOTAK_new.csv")

b4<-read.csv("NSE_YESBANK_new.csv")

b1
b2
b3
b4
