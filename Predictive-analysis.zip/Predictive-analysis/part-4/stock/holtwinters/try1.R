p <- read.csv("NSE_YESBANK_new.csv")
p <- p[,c( "High")]
p
pseries <- ts(p,  start=c(2001,1),frequency=50,end=c(2010) )
pseries
plot(pseries)
hw <- HoltWinters(pseries)
plot(hw)
forecast <- predict(hw, n.ahead = 12, prediction.interval = T, level = 0.95)
plot(hw, forecast)
colnames(forecast)

Fore <- forecast[,2]
Fore
length <- length(Fore)
length
length1 <- length(p)
length1
library("pROC")

q <- p[length,]
q
#f3 <- read.csv("f3.csv")
#colnames(f3)
plot(roc(p[c(1,1:12)] , Fore))

