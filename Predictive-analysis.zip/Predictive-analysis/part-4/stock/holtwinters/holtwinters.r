setwd("C:/Users/Rajani/Desktop/stock/holtwinters")
p <- read.csv("NSE_YESBANK_new.csv")
#selecting the closing price
p <- p[,c( "Close")]
p
#creating a time series object
pseries <- ts(p,  start=c(2001,1),frequency=4,end=c(2010) )
pseries
#ploting the graph
plot(pseries)
#Holt-Winters' method involves three smoothing parameters to smooth the data, the trend, and the seasonal index. 
#applying holt-winters
hw <- HoltWinters(pseries)
plot(hw)
#applying predict function and use the default 0.95 confidence level
forecast <- predict(hw, n.ahead = 12, prediction.interval = T, level = 0.95 , interval='confidence')
#ploting the forecast
plot(hw, forecast)
forecast

library("forecast")
for1 <- forecast.HoltWinters(hw, h=24)
plot.forecast(for1)


#####################################################################################################
#analysis for kotak bank

p <- read.csv("NSE_KOTAK_new.csv")
p <- p[,c( "High")]
p
pseries <- ts(p,  start=c(2001,1),frequency=50,end=c(2010) )
pseries
plot(pseries)
hw <- HoltWinters(pseries)
plot(hw)
forecast <- predict(hw, n.ahead = 12, prediction.interval = T, level = 0.95)
plot(hw, forecast)
colnames(forecast)


