# x, y, z variables
("C:/Users/Rajani/Desktop/stock/comapare-2")
library("plot3D")

date3<- as.Date(b3$Date,"%Y-%m-%d")
b3$year<-as.numeric(format(date3, "%Y"))
b3_years<-subset(b3,b3$year>=2010)

date1<- as.Date(b1$Date,"%Y-%m-%d")
b1$year<-as.numeric(format(date1, "%Y"))
b1_years<-subset(b1,b1$year>=2010)


date4<- as.Date(b4$Date,"%Y-%m-%d")
b4$year<-as.numeric(format(date4, "%Y"))
b4_years<-subset(b4,b4$year>=2010)

x <- b1_years$Last[500:1000]
y <- b3_years$Last[500:1000]
b1_years
b3_years
z <- b4_years$Last[500:1000]
# Compute the linear regression (z = ax + by + d)
fit <- lm(z ~ x + y)
# predict values on regular xy grid
grid.lines = 26
x.pred <- seq(min(x), max(x), length.out = grid.lines)
y.pred <- seq(min(y), max(y), length.out = grid.lines)
xy <- expand.grid( x = x.pred, y = y.pred)
z.pred <- matrix(predict(fit, newdata = xy), 
                 nrow = grid.lines, ncol = grid.lines)
# fitted points for droplines to surface
fitpoints <- predict(fit)
# scatter plot with regression plane
scatter3D(x, y, z, pch = 18, cex = 2, 
          theta = 20, phi = 20, ticktype = "detailed",
          xlab = "open", ylab = "close", zlab = "Total in lakhs",  
          surf = list(x = x.pred, y = y.pred, z = z.pred,  
                      facets = NA, fit = fitpoints), main = "")
legend("topleft", inset=.05,      # location and inset
       bty="n", cex=.5,              # suppress legend box, shrink text 50%
       title="Spread of values",
       c("200", "400", "800"), fill=c("blue", "green", "red"))

###############################################

# x, y, z variables
library(plot3D)


x <- b1_years$Open[500:1000]
y <- b1_years$Close[500:1000]
z <- b1_years$High[500:1000]
# Compute the linear regression (z = ax + by + d)
fit <- lm(z ~ x + y)
# predict values on regular xy grid
grid.lines = 26
x.pred <- seq(min(x), max(x), length.out = grid.lines)
y.pred <- seq(min(y), max(y), length.out = grid.lines)
xy <- expand.grid( x = x.pred, y = y.pred)
z.pred <- matrix(predict(fit, newdata = xy), 
                 nrow = grid.lines, ncol = grid.lines)
# fitted points for droplines to surface
fitpoints <- predict(fit)
# scatter plot with regression plane
scatter3D(x, y, z, pch = 18, cex = 2, 
          theta = 20, phi = 20, ticktype = "detailed",
          xlab = "open", ylab = "close", zlab = "Total in lakhs",  
          surf = list(x = x.pred, y = y.pred, z = z.pred,  
                      facets = NA, fit = fitpoints), main = "")
legend("topleft", inset=.05,      # location and inset
       bty="n", cex=.5,              # suppress legend box, shrink text 50%
       title="Spread of values",
       c("200", "400", "800"), fill=c("blue", "green", "red"))
######################################################



