setwd("C:/Users/Rajani/Desktop/stock/compare-1")
library(ggplot2)


ggplot(b1,aes(Open,Close)) + 
       geom_line(aes(color="bank1")) +
       geom_line(data=b4,aes(color="bank4")) +
       labs(color="Legend") +
       scale_colour_manual("", breaks = c("Corp bank", "Yes bank"),values = c("blue", "brown")) +
       ggtitle("Opening and Closing Stock Prices") + 
       theme(plot.title = element_text(lineheight=.7, face="bold"))

ggplot(b3,aes(Open,Close)) + 
  geom_line(aes(color="bank3")) +
  geom_line(data=b4,aes(color="bank4")) +
  labs(color="Legend") +
  scale_colour_manual("", breaks = c("kotak bank", "yes bank"),values = c("blue", "brown")) +
  ggtitle("Opening and Closing Stock Prices") + 
  theme(plot.title = element_text(lineheight=.7, face="bold"))

ggplot(b2,aes(Open,Close)) + 
  geom_line(aes(color="bank2")) +
  geom_line(data=b3,aes(color="bank3")) +
  labs(color="Legend") +
  scale_colour_manual("", breaks = c("Ebank", "Kotak bank"),values = c("blue", "brown")) +
  ggtitle("Opening and Closing Stock Prices") + 
  theme(plot.title = element_text(lineheight=.7, face="bold"))

ggplot(b1,aes(Open,Close)) + 
  geom_line(aes(color="bank1")) +
  geom_line(data=b2,aes(color="bank2")) +
  labs(color="Legend") +
  geom_line(data=b3,aes(color="bank3")) +
  labs(color="Legend") +
  geom_line(data=b4,aes(color="bank4")) +
  labs(color="Legend") +
  scale_colour_manual("", breaks = c("Corp bank", "Ebank" , "Kotak bank" ,"Yes bank"),values = c("blue", "brown" ,"yellow" , "black")) +
  ggtitle("Opening and Closing Stock Prices") + 
  theme(plot.title = element_text(lineheight=.7, face="bold"))

