setwd("C:/Users/Rajani/Desktop/stock/auto-correlation")
require(quantmod)

  nse_corp<-read.csv("NSE_CORPBANK_new.csv")
  b1<-nse_corp[-4644,1:8]

#Autocorrelation, it is the similarity between observations as a function of the time lag between them.
# bank1 - NSE_CORPBANK.csb
date1<- as.Date(b1$Date,"%Y-%m-%d")
b1$year<-as.numeric(format(date1, "%Y"))
b1_years<-subset(b1,b1$year>=2010)
b1_years
name <- read.csv("NSE_KOTAK_new.csv")

colnames(name)[colnames(name)=="Open"] <- "Adjusted"
colnames(name)

spy.rets = ROC(Ad(name),na.pad=F)
#The function acf computes estimates of the autocovariance or autocorrelation function.
#We compute it for closing prices.
aa = acf(tail(spy.rets,500),main="ACF computed over the last 500 days")
aa

###################################################################################

#bank4

return <- 100*diff(log(b4[,4]))

plot(as.Date(b4$Date[-1]) , return , xlab="Dates" , ylab="open" , col = "red" , main = "daily return")
acf(return , main="prediction")
#The blue dotted line is the 95% confidence interval. 
#We can see that there is the 4th and the 12th lag significant in the ACF plot .
summary(lm(return[10:length(return)] ~ return[10:length(return)-1] + return[10:length(return)-2]+ return[10:length(return)-3] + return[10:length(return)-4] + return[10:length(return)-5] + return[10:length(return)-6] +return[10:length(return)-7]+ return[10:length(return)-8]+return[10:length(return)-9] ))


