setwd("C:/Users/Rajani/Desktop/stock/compare-3")

library("plot3D")

date1<- as.Date(b1$Date,"%Y-%m-%d")
b1$year<-as.numeric(format(date1, "%Y"))
b1_years<-subset(b1,b1$year>=2010)

date3<- as.Date(b3$Date,"%Y-%m-%d")
b3$year<-as.numeric(format(date3, "%Y"))
b3_years<-subset(b3,b3$year>=2010)
b3_years

date4<- as.Date(b4$Date,"%Y-%m-%d")
b4$year<-as.numeric(format(date4, "%Y"))
b4_years<-subset(b4,b4$year>=2010)

x <- h.1 <- b1_years$High[1:500]
y <- h.2 <- b4_years$High[1:500]
z <- h.3 <- b3_years$High[1:500]

length(x)
length(y)
length(z)
z
scatter3D(x, y, z, phi = 0, bty = "g",  type = "h", 
          ticktype = "detailed", pch = 19, cex = 0.5)

####################################################################################


####################################################################################


library("plot3D")

date1<- as.Date(b1$Date,"%Y-%m-%d")
b1$year<-as.numeric(format(date1, "%Y"))
b1_years<-subset(b1,b1$year>=2010)

date2<- as.Date(b3$Date,"%Y-%m-%d")
b3$year<-as.numeric(format(date2, "%Y"))
b3_years<-subset(b3,b3$year>=2010)

date3<- as.Date(b4$Date,"%Y-%m-%d")
b4$year<-as.numeric(format(date3, "%Y"))
length(b1$year)
length(b3$year)
length(b4$year)
b4_years<-subset(b4,b4$year>=2010)
x <- b4$year[1:500]

#x <- h.1 <- b1_years$High[1:500]
y <- h.2 <- b4_years$Open[1:500]
z <- h.3 <- b3_years$Open[1:500]

length(x)
length(y)
length(z)

scatter3D(x, y, z, phi = 0, bty = "g",  type = "h", 
          ticktype = "detailed", pch = 19, cex = 0.5)



########################################################################

library("plot3D")


x <- h.1 <- b1_years$Last[1:1000]
y <- h.2 <- b3_years$Last[1:1000]
z <- h.3 <- b4_years$Last[1:1000]


scatter3D(x, y, z, phi = 0, bty = "g",  type = "h", 
          ticktype = "detailed", pch = 19, cex = 0.5,col = c("blue", "green", "yellow"),
          colkey = list(at = c(2, 3, 4), side = 1, 
                        addlines = TRUE, length = 0.5, width = 0.5,
                        labels = c("", "", "")))
################################################################################

library("plot3D")


date1<- as.Date(b1$Date,"%Y-%m-%d")
b1$year<-as.numeric(format(date1, "%Y"))
b1_years<-subset(b1,b1$year>=2010)

date2<- as.Date(b3$Date,"%Y-%m-%d")
b3$year<-as.numeric(format(date2, "%Y"))
b3_years<-subset(b3,b3$year>=2010)

date4<- as.Date(b4$Date,"%Y-%m-%d")
b4$year<-as.numeric(format(date4, "%Y"))
b4_years<-subset(b4,b4$year>=2010)

NROW(b1_years)
NROW(b3_years)
NROW(b4_years)

print(b1_years)
x <- h.1 <- b1_years$Total.Trade.Quantity[1:1000]
y <- h.2 <- b3_years$Total.Trade.Quantity[1:1000]
z <- h.3 <- b4_years$Total.Trade.Quantity[1:1000]


scatter3D(x, y, z, phi = 0, bty = "g",  type = "h", 
          ticktype = "detailed", pch = 19, cex = 0.5,col = c("#1B9E77", "#D95F02", "#7570B3"),
          colkey = list(at = c(2, 3, 4), side = 1, 
                        addlines = TRUE, length = 0.5, width = 0.5,
                        labels = c("", "", "")))




